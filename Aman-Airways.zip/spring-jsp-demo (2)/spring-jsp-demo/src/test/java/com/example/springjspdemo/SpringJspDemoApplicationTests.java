package com.example.springjspdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJspDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
